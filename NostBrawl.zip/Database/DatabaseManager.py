import json
import sqlite3 as sql
import os, datetime
import string
import pymysql
from Logic.Player import Players


class DataBase:

    def loadAccount(self):
        con = pymysql.connect(
        host=('127.0.0.1'),
        user=("root"),
        password=("я дудка"),
        database=('nostbrawl'))
        with con:    
            cur = con.cursor()
            cur.execute ('''CREATE TABLE IF NOT EXISTS players(
            id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
             token CHAR(200),
             `name` CHAR(200),
             `leagueReward` INT,
             `lowID` INT,
             `tgid` INT,
             `clubID` INT,
             `clubRole` INT,
             `playerExp` INT,
             `soloWins` INT,
             `duoWins` INT,
             `TvsTWins` INT,
             `gems` INT,
             `gold` INT,
             `tokensdoubler` INT,
             `battleTokens` INT,
             `tickets` INT,
             `brawlerID` INT,
             `skinID` INT,
             `trophies` INT,
             `highest_trophies` INT,
             `profileIcon` INT,
             `namecolor` INT,
             `brawlBoxes` INT,
             `bigBoxes` INT,
             `starpower` INT,
             `DoNotDistrub` INT,
             `roomID` INT,
             `brawlersSkins` JSON,
             `brawlersTrophies` JSON,
             `brawlersTrophiesForRank` JSON,
             `brawlersUpgradePoints` JSON,
             `brawlerPowerLevel` JSON,
             `brawlerStarPower` JSON,
             `UnlockedBrawlers` JSON,
             `UnlockedSkins` JSON,
             `Friends` JSON,
             `online` INT,
             `Notifications` JSON
             )''')
            cur.execute(f"SELECT * FROM players WHERE token = '{self.player.token}'") 
            rows = cur.fetchall()
            
            for row in rows:
                row_value = 0
                self.player.id =  row[row_value]
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.token =  row[row_value]
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.name =  row[row_value]
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.trophy_road =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.low_id =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.tgid =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.club_low_id =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.club_role =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.player_experience =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.solo_wins =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.duo_wins =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.ThreeVSThree_wins =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.gems =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.gold =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.tokensdoubler =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.battle_tokens =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.tickets =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.brawler_id =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.skin_id =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.trophies =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.highest_trophies =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.profile_icon =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.name_color =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.brawl_boxes =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.big_boxes =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.starpower =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.do_not_distrub =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.room_id =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.brawlers_skins =  json.loads(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.brawlers_trophies =  json.loads(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.brawlers_trophies_in_rank =  json.loads(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.brawlers_upgradium =  json.loads(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.Brawler_level =  json.loads(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.Brawler_starPower =  json.loads(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.BrawlersUnlockedState =  json.loads(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.UnlockedSkins =  json.loads(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.Friends =  json.loads(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.online =  int(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
                self.player.Notifications =  json.loads(row[row_value])
                row_newvalue = row_value + 1
                row_value = row_newvalue
            if self.player.trophies >= self.player.highest_trophies:
                self.player.highest_trophies = self.player.trophies
                DataBase.replaceValue(self, 'highest_trophies', self.player.highest_trophies)

    def createAccount(self):
        Players.CreateNewBrawlersList()
        con = pymysql.connect(host=('127.0.0.1'),
        user=("root"),
        password=("я дудка"),
        database=('nostbrawl'))
        with con.cursor() as cursor:
            cursor.execute ('''CREATE TABLE IF NOT EXISTS players (
            id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
            token CHAR(200),
            name CHAR(200),
            `leagueReward` INT,
            `lowID` INT,
            `tgid` INT,
            `clubID` INT,
            `clubRole` INT,
            `playerExp` INT,
            `soloWins` INT,
            `duoWins` INT,
            `TvsTWins` INT,
            `gems` INT,
            `gold` INT,
            `tokensdoubler` INT,
            `battleTokens` INT,
            `tickets` INT,
            `brawlerID` INT,
            `skinID` INT,
            `trophies` INT,
            `highest_trophies` INT,
            `profileIcon` INT,
            `namecolor` INT,
            `brawlBoxes` INT,
            `bigBoxes` INT,
            `starpower` INT,
            `DoNotDistrub` INT,
            `roomID` INT,
            `brawlersSkins` JSON,
            `brawlersTrophies` JSON,
            `brawlersTrophiesForRank` JSON,
            `brawlersUpgradePoints` JSON,
            `brawlerPowerLevel` JSON,
            `brawlerStarPower` JSON,
            `UnlockedBrawlers` JSON,
            `UnlockedSkins` JSON,
            `Friends` JSON,
            `online` INT,
            `Notifications` JSON
            )''')
            sql = f"""INSERT INTO `players` (
            `token`,
            `name`,
            `leagueReward`,
            `lowID`,
            `tgid`,
            `clubID`,
            `clubRole`,
            `playerExp`,
            `soloWins`,
            `duoWins`,
            `TvsTWins`,
            `gems`,
            `gold`,
            `tokensdoubler`,
            `battleTokens`,
            `tickets`,
            `brawlerID`,
            `skinID`,
            `trophies`,
            `highest_trophies`,
            `profileIcon`,
            `namecolor`,
            `brawlBoxes`,
            `bigBoxes`,
            `starpower`,
            `DoNotDistrub`,
            `roomID`,
            `brawlersSkins`,
            `brawlersTrophies`,
            `brawlersTrophiesForRank`,
            `brawlersUpgradePoints`,
            `brawlerPowerLevel`,
            `brawlerStarPower`,
            `UnlockedBrawlers`,
            `UnlockedSkins`,
            `Friends`,
            `online`,
            `Notifications`
            )
            VALUES (
            '{self.player.token}',
            '{self.player.name}',
            '{self.player.trophy_road}',
            '{self.player.low_id}',
            '{self.player.tgid}',
            '{self.player.club_low_id}',
            '{self.player.club_role}',
            '{self.player.player_experience}',
            '{self.player.solo_wins}',
            '{self.player.duo_wins}',
            '{self.player.ThreeVSThree_wins}',
            '{self.player.gems}',
            '{self.player.gold}',
            '{self.player.tokensdoubler}',
            '{self.player.battle_tokens}',
            '{self.player.tickets}',
            '{self.player.brawler_id}',
            '{self.player.skin_id}',
            '{self.player.trophies}',
            '{self.player.highest_trophies}',
            '{self.player.profile_icon}',
            '{self.player.name_color}',
            '{self.player.brawl_boxes}',
            '{self.player.big_boxes}',
            '{self.player.starpower}',
            '{self.player.do_not_distrub}',
            '{self.player.room_id}',
            """ + """
            '{"0": 0, "1": 0, "2": 0, "3": 0, "4": 0, "5": 0, "6": 0, "7": 0, "8": 0, "9": 0, "10": 0, "11": 0, "12": 0, "13": 0, "14": 0, "15": 0, "16": 0, "17": 0, "18": 0, "19": 0, "20": 0, "21": 0, "23": 0, "24": 0, "25": 0}',
            '{"0": 0, "1": 0, "2": 0, "3": 0, "4": 0, "5": 0, "6": 0, "7": 0, "8": 0, "9": 0, "10": 0, "11": 0, "12": 0, "13": 0, "14": 0, "15": 0, "16": 0, "17": 0, "18": 0, "19": 0, "20": 0, "21": 0, "23": 0, "24": 0, "25": 0}',
            '{"0": 0, "1": 0, "2": 0, "3": 0, "4": 0, "5": 0, "6": 0, "7": 0, "8": 0, "9": 0, "10": 0, "11": 0, "12": 0, "13": 0, "14": 0, "15": 0, "16": 0, "17": 0, "18": 0, "19": 0, "20": 0, "21": 0, "23": 0, "24": 0, "25": 0}',
            '{"0": 0, "1": 0, "2": 0, "3": 0, "4": 0, "5": 0, "6": 0, "7": 0, "8": 0, "9": 0, "10": 0, "11": 0, "12": 0, "13": 0, "14": 0, "15": 0, "16": 0, "17": 0, "18": 0, "19": 0, "20": 0, "21": 0, "23": 0, "24": 0, "25": 0}',
            '{"0": 0, "1": 0, "2": 0, "3": 0, "4": 0, "5": 0, "6": 0, "7": 0, "8": 0, "9": 0, "10": 0, "11": 0, "12": 0, "13": 0, "14": 0, "15": 0, "16": 0, "17": 0, "18": 0, "19": 0, "20": 0, "21": 0, "23": 0, "24": 0, "25": 0}',
            '{"0": 0, "1": 0, "2": 0, "3": 0, "4": 0, "5": 0, "6": 0, "7": 0, "8": 0, "9": 0, "10": 0, "11": 0, "12": 0, "13": 0, "14": 0, "15": 0, "16": 0, "17": 0, "18": 0, "19": 0, "20": 0, "21": 0, "23": 0, "24": 0, "25": 0}',
            '{"0": 1, "1": 0, "2": 0, "3": 0, "4": 0, "5": 0, "6": 0, "7": 0, "8": 0, "9": 0, "10": 0, "11": 0, "12": 0, "13": 0, "14": 0, "15": 0, "16": 0, "17": 0, "18": 0, "19": 0, "20": 0, "21": 0, "23": 0, "24": 0, "25": 0}',
            '{"Skins": []}',
            '{}',
            """ + f"""
            '{self.player.online}',
            """ + """
            '{}'
            )"""
            cursor.execute(sql)
            cursor.execute('DELETE FROM players WHERE name = "DUDOZ"')
        con.commit()

    def replaceValue(self, value_name, new_value):
        con = pymysql.connect(host=('127.0.0.1'),
        user=("root"),
        password=("я дудка"),
        database=('nostbrawl'))
        with con.cursor() as cursor:
            if value_name in ["brawlersTrophies","brawlersTrophiesForRank","brawlersSkins","brawlerPowerLevel","brawlersUpgradePoints","UnlockedBrawlers","brawlerStarPower"]:
                cursor.execute(f"SELECT {value_name} FROM players WHERE token = '{self.player.token}'")
                zalupka = cursor.fetchall()
                data = json.loads(zalupka[0][0])
                data[value_name] = new_value
                new_data = json.dumps(data[value_name])
                sql = f"UPDATE `players` SET `{value_name}`= '{new_data}' WHERE token = '{self.player.token}'"
                print(sql)
                cursor.execute(sql)
            elif value_name == "UnlockedSkins":
                cursor.execute(f"SELECT {value_name} FROM players WHERE token = '{self.player.token}'")
                zalupka = cursor.fetchall()
                data = json.loads(zalupka[0][0])
                data[value_name] = new_value
                new_data = json.dumps(data[value_name])
                sql = f"UPDATE `players` SET `{value_name}`= '{new_data}' WHERE token = '{self.player.token}'"
                cursor.execute(sql)
            try:
                sql = f'UPDATE `players` SET `{value_name}`= "{new_value}" WHERE token = "{self.player.token}"'
                cursor.execute(sql)
            except Exception:
                pass
        con.commit()

    def replaceOtherValue(self, low_id, value_name, new_value):
        con = pymysql.connect(host=('127.0.0.1'),
        user=("root"),
        password=("я дудка"),
        database=('nostbrawl'))
        with con.cursor() as cursor:
            if value_name in ["brawlersTrophies","brawlersTrophiesForRank","brawlersSkins","brawlerPowerLevel","brawlersUpgradePoints","UnlockedBrawlers","brawlerStarPower"]:
                cursor.execute(f"SELECT {value_name} FROM players WHERE lowID = {low_id}")
                zalupka = cursor.fetchall()
                data = json.loads(zalupka[0][0])
                data[value_name] = new_value
                new_data = json.dumps(data[value_name])
                sql = f"UPDATE `players` SET `{value_name}`= '{new_data}' WHERE lowID = {low_id}"
                cursor.execute(sql)
            elif value_name == "UnlockedSkins":
                cursor.execute(f"SELECT {value_name} FROM players WHERE lowID = {low_id}")
                zalupka = cursor.fetchall()
                data = json.loads(zalupka[0][0])
                data[value_name] = new_value
                new_data = json.dumps(data[value_name])
                sql = f"UPDATE `players` SET `{value_name}`= '{new_data}' WHERE lowID = {low_id}"
                cursor.execute(sql)
            try:
                sql = f'UPDATE `players` SET `{value_name}`= "{new_value}" WHERE lowID = {low_id}'
                cursor.execute(sql)
            except Exception:
                pass
        con.commit()

    def DeleteTrash(self):
        con = pymysql.connect(host=('127.0.0.1'),
        user=("root"),
        password=("я дудка"),
        database=('nostbrawl'))
        try:
            with con.cursor() as cursor:
                cursor.execute('SELECT name FROM players WHERE name = "Guest"')
                count = cursor.fetchall()
                if len(count) >= 15:
                    cursor.execute('DELETE FROM players WHERE name = "Guest"')
                else:
                    pass
        except:
            pass
        con.commit()

    def fixAccount(self):
        DataBase.replaceValue(self, "trophies", 0)
        DataBase.replaceValue(self, "highest_trophies", 0)
        DataBase.replaceValue(self, "clubID", 0)
        DataBase.replaceValue(self, "gold", 100)
        DataBase.replaceValue(self, "gems", 0)
        DataBase.replaceValue(self, "tickets", 5)
        DataBase.replaceValue(self, "bigBoxes", 0)
        DataBase.replaceValue(self, "brawlBoxes", 0)
        DataBase.replaceValue(self, "tokensdoubler", 0)
        DataBase.replaceValue(self, "tgid", 0)
        DataBase.replaceValue(self, "playerExp", 0)
        self.player.brawlers_trophies[str(self.player.brawler_id)] = 0
        self.player.brawlers_trophies_in_rank[str(self.player.brawler_id)] = 0
        DataBase.replaceValue(self, 'brawlersTrophies', self.player.brawlers_trophies)
        DataBase.replaceValue(self, 'brawlersTrophiesForRank', self.player.brawlers_trophies_in_rank)

    def checkID(self, new_id):
        con = pymysql.connect(host=('127.0.0.1'),
        user=("root"),
        password=("я дудка"),
        database=('nostbrawl'))
        with con.cursor() as cursor:
            try:
                cursor.execute(f"SELECT lowID FROM `players` WHERE lowID = '{new_id}'")
                count = len(cursor.fetchall())
                if count == 0:
                    return 1
                else:
                    return 0
            except:
                return 1

    def getFriends(self):
        self.friendList = []
        index = []
        for i in self.player.Friends:
            index.append(i)
        for i in index[::-1]:
            if index[::-1].index(i)<=4:
                self.friendList.append(json.dumps(self.player.Friends[str(i)]))
        self.friendList.sort(reverse=False)
        return self.friendList

    def setFriendData(self, lowID):
        player = DataBase.loadAccount(self)
        friendData = json.loads(player[36])
        l = str(len(friendData))
        friendData[l] = {}
        friendData[l]["lowID"] = lowID
        new_data = json.dumps(friendData)
        DataBase.replaceValue(self, "Friends", new_data)

    def sendNotifData(self, lowID, ID, text, type):
        player = DataBase.loadById(self, lowID)
        notifData = json.loads(player[38])
        l = str(len(notifData))
        notifData[l] = {}
        notifData[l]["ID"] = ID
        notifData[l]["Index"] = 3
        notifData[l]["Read"] = False
        notifData[l]["Time"] = datetime.datetime.timestamp(datetime.datetime.now())
        notifData[l]["Text"] = text
        if ID == 81:
            notifData[l]["Type"] = type
        DataBase.replaceValue(self, "Notifications", notifData)

    def loadOldAccount(self, nost_id):
        con = pymysql.connect(host=('127.0.0.1'),
        user=("root"),
        password=("я дудка"),
        database=('nostbrawl'))
        with con.cursor() as cursor:
            cursor.execute(f"SELECT tgid FROM `players` WHERE tgid = '{nost_id}'")
            count = len(cursor.fetchall())
            if count != 0:
                cursor.execute(f'UPDATE `players` SET `token` = "{self.player.token}" WHERE tgid = {nost_id}')
            else:
                pass

    def replaceValues():
        con = pymysql.connect(host=('127.0.0.1'),
        user=("root"),
        password=("я дудка"),
        database=('nostbrawl'))
        with con.cursor() as cursor:
            cursor.execute("UPDATE `players` SET online = 0")
            cursor.execute("UPDATE `players` SET roomID = 0")
        con.commit()

    def getLeaders(self):
        con = pymysql.connect(host=('127.0.0.1'),
        user=("root"),
        password=("я дудка"),
        database=('nostbrawl'))
        with con.cursor() as cursor:
            cursor.execute("SELECT lowID, name, trophies, profileIcon, namecolor, clubID FROM `players` ORDER BY trophies DESC LIMIT 100")
            return cursor.fetchall()

    def loadById(self, ID):
        con = pymysql.connect(host=('127.0.0.1'),
        user=("root"),
        password=("я дудка"),
        database=('nostbrawl'))
        with con.cursor() as cursor:
            cursor.execute(f"SELECT * FROM `players` WHERE lowID = '{ID}'")
            return cursor.fetchall()

    def loadMembersById(self, ID):
        con = pymysql.connect(host=('127.0.0.1'),
        user=("root"),
        password=("я дудка"),
        database=('nostbrawl'))
        with con.cursor() as cursor:
            cursor.execute(f"SELECT * FROM `players` WHERE lowID = '{ID}'")
            return cursor.fetchone()

    # Club
    def createClub(self, clubid):
        self.conn = sql.connect("Database/clubs.db")
        self.con = sql.connect(f"Database/Chats/{clubid}.db")
        self.cur = self.conn.cursor()
        self.c = self.con.cursor()
        self.cur.execute(f"CREATE TABLE IF NOT EXISTS clubs (clubID INT, name TEXT, description TEXT, region TEXT, badgeID INT, type INT, trophiesneeded INT, trophies INT, members JSON, notif JSON)")
        self.c.execute(f"CREATE TABLE IF NOT EXISTS chats (Event INT, Tick INT, plrid INT, plrname TEXT, plrrole INT, Msg TEXT)")
        self.con.commit()
        self.conn.commit()
        data = {"members": {self.player.low_id:self.player.name}}
        notif = {}
        var = clubid,str(self.clubName),str(self.clubdescription),"RU",self.clubbadgeID,self.clubtype,self.clubtrophiesneeded,self.player.trophies,json.dumps(data),json.dumps(notif)
        self.cur.execute(f"INSERT INTO clubs VALUES (?,?,?,?,?,?,?,?,?,?)", var)
        self.conn.commit()
        msgData = {
            "clubID": clubid,
            "info": {
                "Total": 1,
                "1": {
                    "Event": 2,
                    "Tick": 1,
                    "PlayerID": self.player.low_id,
                    "PlayerName": self.player.name,
                    "PlayerRole": 2,
                    "Message": "Welcome to your new club!"
                }
            }
        }
        sss = "INSERT INTO chats VALUES (?, ?, ?,?,?,?)"
        var = 2, 1, self.player.low_id, str(self.player.name), 2, "Club Created!"
        self.c.execute(sss, var)
        self.con.commit()
        if str(self.clubName) == "лох":
            self.c.execute("DELETE FROM chats")
            self.cur.execute(f"DELETE FROM clubs WHERE clubID={clubid}")
            self.con.commit()
            self.conn.commit()
        else:
            pass

    def setNotifData(self, text, by):
    	self.conn = sql.connect("Database/clubs.db")
    	self.cur = self.conn.cursor()
    	self.cur.execute("SELECT * FROM clubs WHERE clubID=?", (self.player.club_low_id,))
    	fetch = self.cur.fetchall()
    	if fetch:
    	   	notifData = json.loads(fetch[0][9])
    	   	l = str(len(notifData))
    	   	notifData[l]={}
    	   	notifData[l]["text"]=text
    	   	notifData[l]["by"]=by
    	   	notifData[l]["timer"]=datetime.datetime.timestamp(datetime.datetime.now())
    	   	self.cur.execute("UPDATE clubs SET notif=? WHERE clubID=?", (json.dumps(notifData),self.player.club_low_id))
    	   	self.conn.commit()
    	   	self.conn.close()

    def CountClub(self):
        self.AllianceCount = 0
        self.club_list = []
        self.conn = sql.connect("Database/clubs.db")
        self.cur = self.conn.cursor()
        try:
                		self.cur.execute(f"SELECT * FROM clubs")
                		fetch = self.cur.fetchall()
                		if len(fetch)>0:
                			for i in fetch:
                				self.club_list.append(int(i[0]))
                				self.AllianceCount+=1
                		self.conn.close()
        except:
            pass

    def loadClub(self, clubid):
        self.conn = sql.connect("Database/clubs.db")
        self.cur = self.conn.cursor()
        
        self.cur.execute(f"SELECT * FROM clubs WHERE clubID={clubid}")
        fetch = self.cur.fetchall()
        if len(fetch)>0:
        		for i in fetch:
        			self.clubmembercount = 0
        			self.plrids = []
        			self.clubName = i[1]
        			self.clubdescription = i[2]
        			self.clubregion = i[3]
        			
        			self.clubbadgeID = i[4]
        			self.clubtype = i[5]
        			self.clubtrophiesneeded = i[6]
        			try:
        				self.notifData = json.loads(i[9])
        			except:
        				self.cur.execute("ALTER TABLE clubs ADD COLUMN notif JSON")
        				self.conn.commit()
        			self.clubtrophies = 0
        			data = json.loads(i[8])
        			for ID in data["members"]:
        			     	if ID != "members":
        			     		self.plrids.append(int(ID))
        			     		self.clubmembercount += 1
        			     		DataBase.GetMemberData(self, int(ID))
        			     		self.clubtrophies += self.plrtrophies
        			#self.cur.execute(f"UPDATE clubs SET trophies={self.clubtrophies} WHERE clubID={clubid}")
        			#self.cur.execute(f"UPDATE clubs SET trophies={self.clubtrophies} WHERE clubID={clubid}")
        			self.conn.commit()
        			self.conn.close()

    def loadClubName(self, clubid):
        self.conn = sql.connect("Database/clubs.db")
        self.cur = self.conn.cursor()

        self.cur.execute(f"SELECT * FROM clubs WHERE clubID={clubid}")
        fetch = self.cur.fetchall()
        if len(fetch)>0:
        		for i in fetch:
        			self.clubName = i[1]
        		self.conn.commit()
        		self.conn.close()

    def AddMember(self, AllianceID, PlayerID, PlayerName, Action):
        self.conn = sql.connect("Database/clubs.db")
        self.con = sql.connect(f"Database/Chats/{AllianceID}.db")
        self.cur= self.conn.cursor()
        self.chat = self.con.cursor()
        self.cur.execute(f"SELECT * FROM clubs WHERE clubID={AllianceID}")
        fetch = self.cur.fetchall()
        if len(fetch)>0:
        	data = json.loads(fetch[0][8])
        	if Action == 0:
        		self.chat.execute(f"DELETE FROM chats")
        		self.cur.execute(f"DELETE FROM clubs WHERE clubID={AllianceID}")
        		self.con.commit()
        		self.conn.commit()
        		os.remove(f"Database/Chats/{AllianceID}.db")
        	elif Action == 1:
        	   data["members"][str(PlayerID)] = PlayerName
        	   self.cur.execute(f"UPDATE clubs SET members=? WHERE clubID=?",(json.dumps(data),AllianceID))
        	   ol = fetch[0][7]
        	   self.cur.execute(f"UPDATE clubs SET trophies={ol+self.player.trophies} WHERE clubID={AllianceID}")
        	   self.conn.commit()
        	elif Action == 2:
        	       data['members'].pop(str(PlayerID))
        	       self.cur.execute(f"UPDATE clubs SET members=? WHERE clubID=?", (json.dumps(data), AllianceID))
        	       ol = fetch[0][7]
        	       self.cur.execute(f"UPDATE clubs SET trophies={ol-self.player.trophies} WHERE clubID={AllianceID}")
        	       self.conn.commit()
        	self.con.close()
        	self.conn.close()

    def GetMemberData(self, Low_id):
        try:
            self.players = DataBase.loadMembersById(self, Low_id)
            if self.players[4] == int(Low_id):
                    self.lowplrid = self.players[4]
                    self.plrrole = self.players[7]
                    self.plrtrophies = self.players[19]
                    self.plrname = self.players[2]
                    self.plricon = self.players[21]
                    self.plrnamecolor = self.players[22]
                    self.plrexperience = self.players[8]
                    self.plrstatus = self.players[37]

        except Exception as e:
            self.lowplrid = 1
            self.plrrole = 1
            self.plrtrophies = 0
            self.plrname = "Falied to load account!"
            self.plricon = 0
            self.plrnamecolor = 0
            self.plrexperience = 999
            self.plrstatus = 0

    def replaceClubValue(self, target, inf1, inf2, inf3, inf4):
        self.conn = sql.connect("Database/clubs.db")
        self.cur= self.conn.cursor()
        query = Query()
        self.cur.execute(f"SELECT * FROM clubs WHERE clubID={self.player.club_low_id}")
        if 1==1:
        	
        	self.cur.execute(f"UPDATE clubs SET description='{inf1}' WHERE clubID={self.player.club_low_id}")
        	self.cur.execute(f"UPDATE clubs SET badgeID={inf2} WHERE clubID={self.player.club_low_id}")
        	self.cur.execute(f"UPDATE clubs SET type={inf3} WHERE clubID={self.player.club_low_id}")
        	self.cur.execute(f"UPDATE clubs SET trophiesneeded={inf4} WHERE clubID={self.player.club_low_id}")
        	
        	self.conn.commit()
        	self.conn.close()

    def GetmsgCount(self, clubID):
        self.con = sql.connect(f"Database/Chats/{clubID}.db")
        self.chat = self.con.cursor()
        self.chat.execute(f"SELECT * FROM chats")
        fetch = self.chat.fetchall()
        if len(fetch)>0:
        	self.MessageCount = len(fetch)
        else:
        	self.MessageCount = 1
        self.con.close()

    def Addmsg(self, clubID, event, tick, Low_id, name, role, msg):
        clubid = self.player.club_low_id
        self.con = sql.connect(f"Database/Chats/{clubid}.db")
        self.chat = self.con.cursor()
        self.chat.execute(f"SELECT * FROM chats")
        fetch = self.chat.fetchall()
        sss = "INSERT INTO chats VALUES (?, ?, ?,?,?,?)"
        var = event, len(fetch)+1, Low_id, name, role, msg
        self.chat.execute(sss, var)
        self.con.commit()
        self.con.close()

    def DeleteAllMsg(self, clubID):
        self.con = sql.connect(f"Database/Chats/{clubID}.db")
        self.chat = self.con.cursor()
        self.chat.execute(f"SELECT * FROM chats")
        fetch = self.chat.fetchall()
        if len(fetch)>=400:
        	self.chat.execute(f"DELETE FROM chats")
        	self.con.commit()