from Packets.Messages.Server.Battle.VisionUpdateMessage import VisionUpdateMessage
from Packets.Messages.Server.Battle.StartLoadingMessage import StartLoadingMessage
from Logic.Battle.Matchmake.Matchmaking import Matchmaking
from Database.DatabaseManager import DataBase

import time
from multiprocessing import Process
import asyncio

class Battle(Process):
    def __init__(self, client, player, state):
        Process.__init__(self)
        self.client = client
        self.player = player
        self.subTick = 0
        self.tick = 0
        self.started = 0
        self.state = state
    
    def run(self):
        if self.state == 1:
            self.startBattle()
        else:
            #Matchmaking(self.client, self.player).start()
            #DataBase.replaceValue(self, "battleID", self.player.matchmake_id)
            self.startBattle()
    
    def startBattle(self):
        self.started = 1
        StartLoadingMessage(self.client, self.player).send()
        while self.started:
            if True:#self.subTick >= 4:
                self.tick += 1
                self.subTick = 0
                self.player.battleTick = self.tick
                #print("Tick: ", self.tick)
            try:
                VisionUpdateMessage(self.client, self.player).send() 
                time.sleep(0.0515)
            except ConnectionResetError:
                print("hello")
                break