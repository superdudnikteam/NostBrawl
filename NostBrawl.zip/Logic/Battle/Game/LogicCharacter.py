from Utils.Writer import Writer
from Utils.BitStream import BitStream

class LogicCharacter:
	def encode(self, stream):
		stream.writePositiveInt(1, 7) # Кол-во игроков
		#plr start
		stream.writePositiveInt(16, 5)
		stream.writePositiveInt(0, 8) # Brawler ID
		#bot start
		stream.writePositiveInt(0, 14)
		
		stream.writePositiveVInt(3125, 4)#
		stream.writePositiveVInt(9500, 4)#
		stream.writePositiveVInt(0, 3)
		stream.writePositiveVInt(0, 4)
		stream.writePositiveInt(10, 4)
		stream.writePositiveInt(0, 1)#isownobj
		stream.writePositiveInt(0, 1)#isownobj
		stream.writePositiveInt(0, 3)
		stream.writePositiveInt(0, 1)
		stream.writeInt(63, 6)
		stream.writePositiveInt(0, 1)#дёргает и не rotate
		stream.writePositiveInt(0, 1)#stan
		stream.writePositiveInt(0, 1)#unk
		stream.writePositiveInt(0, 1)#star power indicator
		stream.writePositiveInt(1, 1)#1
		stream.writePositiveInt(1, 1)
		stream.writePositiveInt(0, 1)
		stream.writePositiveInt(0, 1)
		stream.writePositiveInt(0, 2)
		stream.writePositiveInt(3600, 13)
		stream.writePositiveInt(3600, 13)
		stream.writePVIntMax255OZ(0)
		stream.writePositiveInt(0, 1)
		stream.writePositiveInt(0, 4)
		stream.writePositiveInt(0, 2)
		stream.writePositiveInt(0, 1)
		stream.writePositiveInt(0, 9)
		stream.writePositiveInt(0, 1)
		stream.writePositiveInt(0, 1)
		stream.writePositiveInt(0, 5)
		stream.writePositiveInt(1, 1)
		stream.writePositiveInt(0, 1)
		stream.writePositiveInt(1, 1)
		stream.writePositiveInt(3000, 12)
		stream.writePositiveInt(1, 1)
		stream.writePositiveInt(0, 1)
		stream.writePositiveInt(1, 1)

		stream.writePositiveInt(0, 8)