from Logic.Battle.Matchmake.Slots import Slots
from Packets.Messages.Server.Battle.BattleTestMessage import BattleTestMessage
from threading import *
import time

class Matchmaking:
    def __init__(self, client, player):
        self.client = client
        self.player = player
    
    def start(self):
        result = Slots(self.client, self.player).addPlayer()
        if result == 1:
            pass
        else:
            Slots(self.client, self.player).createSlot()
        while True:
            count = Slots(self.client, self.player).checkCount()
            try:
                if count == self.player.mmplayers:
                    BattleTestMessage(self.client, self.player, count).send()
                    time.sleep(1)
                    break
                else:
                    BattleTestMessage(self.client, self.player, count).send()
                    time.sleep(0.3)
            except OSError:
                pass