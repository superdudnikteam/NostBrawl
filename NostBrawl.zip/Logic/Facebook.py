class Facebook:
    AppID = "103121310241222"