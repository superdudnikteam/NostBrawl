from Database.DatabaseManager import DataBase

from Utils.Writer import Writer

class LogicBrawlerDataCommand(Writer):
    def __init__(self, client, player, ID, state):
        super().__init__(client)
        self.id = 24111
        self.player = player
        self.brawlerID = ID
        self.state = state

    def encode(self):
        self.writeVint(203) # CommandID
        self.writeVint(0)   # Unknown
        self.writeVint(1)   # Multipler
        self.writeVint(100) # BoxID
        self.writeVint(1)
        self.writeVint(1)
        try:
          self.player.BrawlersUnlockedState[str(self.brawlerID)] = 1
          self.writeScId(16, self.brawlerID)#brawler
          DataBase.replaceValue(self, 'UnlockedBrawlers', self.player.BrawlersUnlockedState)
        except:
          self.writeScId(16, 0)#shelly xxx bruh
        self.writeVint(1) # Reward ID
        self.writeVint(0) # CsvID 29
        self.writeVint(0) # CsvID 52
        if self.state == 1:
            self.writeVint(self.player.trophy_road)
        else:
            self.writeVint(0)