from Packets.Messages.Server.Alliance.Alliance_Chat_Server_Message import AllianceChatServerMessage
from Packets.Messages.Server.AllianceBot.Alliance_Bot_Chat_Server_Message import AllianceBotChatServerMessage
from Packets.Messages.Server.Login.LoginFailedMessage import LoginFailedMessage

from Database.DatabaseManager import DataBase
from Utils.Reader import BSMessageReader

class AllianceChatMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.bot_msg = ''
        self.send_ofs = False
        self.IsAcmd = False

    def decode(self):
        self.msg = self.read_string()

        if self.msg.lower().startswith('/load'):
            try:
                win = self.msg.split(" ", 4)[1:]
                nost_id = int(win[0])
                DataBase.loadOldAccount(self, nost_id)
                self.send_ofs = True
                self.IsAcmd = True
            except:
                pass

    def process(self):
        if self.send_ofs == False and self.IsAcmd == False:
            DataBase.Addmsg(self, self.player.club_low_id, 2, 0, self.player.low_id, self.player.name, self.player.club_role, self.msg)
            DataBase.loadClub(self, self.player.club_low_id)
            for i in self.plrids:
                AllianceChatServerMessage(self.client, self.player, self.msg, self.player.club_low_id).sendWithLowID(i)
                DataBase.DeleteAllMsg(self, self.player.club_low_id)

        if self.bot_msg != '':
            AllianceChatServerMessage(self.client, self.player, self.msg, self.player.club_low_id, True).send()
            AllianceBotChatServerMessage(self.client, self.player, self.bot_msg).send()

        if self.send_ofs:
            self.player.err_code = 1
            LoginFailedMessage(self.client, self.player, 'Всё готово! Если айди правильный, то при следующем заходе в игру будет загружен привязанный к нему аккаунт').send()