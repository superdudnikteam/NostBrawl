from Utils.Reader import BSMessageReader
from Packets.Messages.Server.Login.ServerHelloMessage import ServerHelloMessage

class ClientHelloMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.client = client
        self.player = player

    def decode(self):
        pass #TODO: Decode this stuff

    def process(self):
        ServerHelloMessage(self.client, self.player).send()