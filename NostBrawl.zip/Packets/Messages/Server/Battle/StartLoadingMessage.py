from Utils.Writer import Writer


class StartLoadingMessage(Writer):
    def __init__(self, client, player):
        super().__init__(client)
        self.id = 20559
        self.client = client
        self.player = player


    def encode(self):
        self.writeInt(1) # Game Mode Total Players
        self.writeInt(0)
        self.writeInt(0)
        
        
        # Logic Player Array
        self.writeInt(1) # Players Count
        
        for i in range(1):
            self.writeLong(0, self.player.low_id) # Player ID
            self.writeVint(1) # Player Index
            self.writeVint(0) # Player Team
            self.writeVint(0) 
            self.writeInt(1000000) # ???
            self.writeScId(16, 0) # Player Brawler
            self.writeScId(29, 29) # Player Skin
            self.writeBoolean(False) # Hero Upgrades
            self.writeString("Nost Brawl") # Player Name
            self.writeVint(100)
            self.writeVint(28000000) # Player Profile Icon
            self.writeVint(43000000) # Player Name Color
        # Player Display Data End
        # Logic Player Array End
        
        
        # Logic Vector Array
        self.writeInt(0) # Array
        self.writeInt(0) # Count
        self.writeInt(0) # Unknown
		
        self.writeVint(0)
        self.writeVint(1) # Map Blocks
        self.writeVint(1) # Joystick Mode
		
        self.writeBoolean(True) # Battle Hints
        self.writeVint(0)
        self.writeVint(0)
        self.writeScId(15, self.player.map_id) # Location ID
        self.writeBoolean(False) # Battle Hints