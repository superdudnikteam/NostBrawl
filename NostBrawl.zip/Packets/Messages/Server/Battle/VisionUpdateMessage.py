from Utils.Writer import Writer
from Utils.BitStream import BitStream
from Logic.Battle.Game.LogicGameObjectManager import LogicGameObjectManager

class VisionUpdateMessage(Writer):
	def __init__(self, client, player):
		super().__init__(client)
		self.id = 24109
		self.player = player

	def encode(self):
		self.writeVint(self.player.battleTick) # Battle Ticks
		self.writeVint(self.player.dudu) # wifi posral jidko
		self.writeVint(0) # Commands Count
		self.writeVint(0) # spectators
		self.writeBoolean(False) # Live Boolean

		stream = BitStream()

		LogicGameObjectManager.encode(self, stream)

		self.writeInt(stream.size())
		self.writeBytes(stream.getBuff())