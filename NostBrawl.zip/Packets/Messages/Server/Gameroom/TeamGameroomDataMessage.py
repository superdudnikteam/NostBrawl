from Utils.Writer import Writer
from Database.DatabaseManager import DataBase

class TeamGameroomDataMessage(Writer):

    def __init__(self, client, player):
        super().__init__(client)
        self.id = 24124
        self.player = player
        self.playerCount = 1

    def encode(self):
        DataBase.loadGameroom(self)
        brawler_trophies = self.player.brawlers_trophies[str(self.player.brawler_id)]
        brawler_trophies_for_rank = self.player.brawlers_trophies_in_rank[str(self.player.brawler_id)]
        brawler_level = self.player.Brawler_level[str(self.player.brawler_id)] + 1

        if self.player.room_id != 0:
            self.writeVint(1)#Team Mode
            self.writeBoolean(True)#?
            self.writeVint(2)#?

            self.writeInt(0)#High Id Room
            self.writeInt(self.player.room_id)#Room ID

            self.writeVint(100)#Timestamp
            self.writeBoolean(True)
            self.writeBoolean(True)

            self.writeVint(self.player.slot_index)#Slot index
            self.writeScId(15, self.mapID)#MapID

            print("MAP", self.mapID)
            
            self.writeVint(self.playerCount)

            for plr in self.plrData.values():
                # Player
                self.writeVint(plr["host"])# Gameroom owner boolean
                self.writeInt(0)                                      # HighID
                self.writeInt(int(plr["lowID"]))# LowID

                self.writeScId(16, plr["brawlerID"])# BrawlerID
                self.writeScId(29, plr["skinID"])
                self.writeVint(brawler_trophies)# Brawler trophies
                self.writeVint(brawler_trophies_for_rank)#Brawler trophies for rank
                self.writeVint(brawler_level)# Power level

                self.writeVint(3)# Player State | 11: Events, 10: Brawlers, 9: Writing..., 8: Training, 7: Spectactor, 6: Offline, 5: End Combat Screen, 4: Searching, 3: Not Ready, 2: AFK, 1: In Combat, 0: OffLine
                self.writeVint(plr["Ready"])    # Is ready
                self.writeVint(0)     # Team | 0: Blue, 1: Red
                self.writeVint(0)

                self.writeString(plr["name"])                  # Player name
                self.writeVint(100)
                self.writeVint(28000000 + plr["profileIcon"])  # Player icon
                self.writeVint(43000000)    #
                
                self.writeScId(0, 0)       # Starpower

            self.writeVint(0)
            self.writeVint(0)
            self.writeVint(0)
            if self.roomType == 0:
                return 1
            else:
                return 0