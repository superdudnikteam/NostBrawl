from Utils.Writer import Writer


class TeamKickOK(Writer):

    def __init__(self, client, player):
        super().__init__(client)
        self.id = 24125
        self.player = player

    def encode(self):
        self.writeInt(1) # Error TID
        self.player.room_id = 0