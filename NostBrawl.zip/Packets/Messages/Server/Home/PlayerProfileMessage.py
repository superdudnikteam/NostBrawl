from os import truncate
from Utils.Writer import Writer
from Database.DatabaseManager import DataBase
import json


class PlayerProfileMessage(Writer):

    def __init__(self, client, player, high_id, low_id, players):
        super().__init__(client)
        self.id = 24113
        self.player = player
        self.high_id = high_id
        self.low_id = low_id
        self.players = players

    def encode(self):
        for player in self.players:
            if self.low_id == player[4]:
                self.UnlockedBrawlersList = []
                UnlockedBrawlers = json.loads(player[34])
                for brawler_id in UnlockedBrawlers:
                    if UnlockedBrawlers[brawler_id] == 1:
                        self.UnlockedBrawlersList.append(int(brawler_id))

                self.writeVint(self.high_id)  # High Id
                self.writeVint(self.low_id)  # Low Id
                self.writeVint(0)  # Unknown

                self.writeVint(len(self.UnlockedBrawlersList))  # Brawlers array

                for brawler_id in self.UnlockedBrawlersList:
                    brawlerTrophies = json.loads(player[29])
                    brawlerTrophiesForRank = json.loads(player[30])
                    brawlerPowerLevel = json.loads(player[32])
                    brawlerStarPower = json.loads(player[33])
                    self.writeScId(16, int(brawler_id))
                    self.writeVint(0)
                    self.writeVint(brawlerTrophies[str(brawler_id)])  # Trophies 
                    self.writeVint(brawlerTrophiesForRank[str(brawler_id)])  # Trophies for rank
                    if brawlerStarPower[str(brawler_id)] >= 1:
                        self.writeVint(2 + brawlerPowerLevel[str(brawler_id)])
                    else:
                        self.writeVint(1 + brawlerPowerLevel[str(brawler_id)])

                self.writeVint(15)

                self.writeVint(1)
                self.writeVint(player[11])  # 3v3 victories

                self.writeVint(2)
                self.writeVint(player[8])  # Player experience

                self.writeVint(3)
                self.writeVint(player[19])  # Trophies

                self.writeVint(4)
                self.writeVint(player[20])  # Highest trophies

                self.writeVint(5)
                self.writeVint(len(self.UnlockedBrawlersList))  # Brawlers list

                self.writeVint(7)
                self.writeVint(28000000 + player[21])  # Profile icon??

                self.writeVint(8)
                self.writeVint(player[9])  # Solo victories

                self.writeVint(9)
                self.writeVint(0)  # Best robo rumble time

                self.writeVint(10)
                self.writeVint(0)  # Best time as big brawler

                self.writeVint(11)
                self.writeVint(player[10])  # Duo victories

                self.writeVint(12)
                self.writeVint(0)  # Highest boss fight lvl passed

                self.writeVint(13)
                self.writeVint(0)  # Highest power player points

                self.writeVint(14)
                self.writeVint(0)  # Highest power play rank

                self.writeVint(15)
                self.writeVint(0)  # most challenge wins

                self.writeVint(16)
                self.writeVint(20)

                self.writeString(player[2])
                self.writeVint(100)
                self.writeVint(28000000 + player[21])  # Profile icon
                self.writeVint(43000000 + player[22])  # Name color

                if player[6] != 0:
                    DataBase.loadClub(self, player[6])

                    self.writeBoolean(True)  # Is in club

                    self.writeInt(0)
                    self.writeInt(player[6])
                    self.writeString(self.clubName)  # club name
                    self.writeVint(8)
                    self.writeVint(self.clubbadgeID)  # Club badgeID
                    self.writeVint(self.clubtype)  # club type | 1 = Open, 2 = invite only, 3 = closed
                    self.writeVint(self.clubmembercount)  # Current members count
                    self.writeVint(self.clubtrophies)
                    self.writeVint(self.clubtrophiesneeded)  # Trophy required
                    self.writeVint(0)  # (Unknown)
                    self.writeString(self.clubregion)  # region
                    self.writeVint(0)  # (Unknown)
                    self.writeVint(25)
                    self.writeVint(player[7])
                else:
                    self.writeVint(0)
                    self.writeVint(0)