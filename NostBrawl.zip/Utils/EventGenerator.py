import json
import random

class EventGenerator:
	def loadEvents(self):
		with open("JSON/events.json", "r") as f:
			data = json.load(f)
			return data

	def generateEvents(self):
		result = EventGenerator.loadEvents(self)
		# Gem Grab
		l = str(len(result))
		result[l] = {}
		result[l]["ID"] = random.choice([7, 8, 9, 10, 11, 12, 40, 48, 70, 72, 82, 83, 112, 114, 115, 116, 117, 122, 137, 138, 139])
		result[l]["Modifier"] = 0
		result[l]["Tokens"] = 10
		result[l]["Collected"] = []
		json.dumps(result)
		# Solo Showdown
		l = str(len(result))
		result[l] = {}
		result[l]["ID"] = random.choice([13, 14, 15, 16, 32, 43, 93, 95, 101, 103, 105, 109, 123, 125])
		result[l]["Modifier"] = 0
		result[l]["Tokens"] = 10
		result[l]["Collected"] = []
		# Bounty
		l = str(len(result))
		result[l] = {}
		result[l]["ID"] = random.choice([0, 4, 22, 80, 81])
		result[l]["Modifier"] = 0
		result[l]["Tokens"] = 10
		result[l]["Collected"] = []
		# Brawl Ball
		l = str(len(result))
		result[l] = {}
		result[l]["ID"] = random.choice([24, 25, 26, 50, 51, 118, 132])
		result[l]["Modifier"] = 0
		result[l]["Tokens"] = 10
		result[l]["Collected"] = []
		# Duo Showdown
		l = str(len(result))
		result[l] = {}
		result[l]["ID"] = random.choice([34, 35, 36, 37, 38, 28, 94, 96, 102, 104, 106, 110, 124, 126])
		result[l]["Modifier"] = 0
		result[l]["Tokens"] = 10
		result[l]["Collected"] = []
		EventGenerator.newEvents(self, result)

	def newEvents(self, result):
		with open("JSON/events.json", "w") as f:
			json.dump(result,f)

	def deleteEvents(self):
		with open("JSON/events.json", "w") as f:
			data = {}
			json.dump(data,f)