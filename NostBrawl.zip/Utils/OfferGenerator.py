import json
import random

class OfferGenerator:
	def loadOffers(self):
		with open("JSON/offers.json", "r") as f:
			data = json.load(f)
			return data

	def generateOffers(self, brawlersUnlocked = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 23, 24, 25], max = 26):
		# Daily Gift
		result = OfferGenerator.loadOffers(self)
		l = str(len(result))
		result[l] = {}
		result[l]["ID"] = 0
		result[l]["OfferTitle"] = "FREE"
		result[l]["Cost"] = 0
		result[l]["OldCost"] = 0
		result[l]["Multiplier"] = 1
		result[l]["BrawlerID"] = 0
		result[l]["SkinID"] = 0
		result[l]["WhoBuyed"] = []
		result[l]["ShopType"] = 0
		result[l]["ShopDisplay"] = 1
		json.dumps(result)
		# Offers
		#ind = 0
		#random.shuffle(brawlersUnlocked)
		#for brawler in brawlersUnlocked:
			#if ind < max:
				#powerpoints = random.randint(25, 100)
				#l = str(len(result))
				#result[l] = {}
				#result[l]["ID"] = 8
				#result[l]["OfferTitle"] = "POWERPOINTS"
				#result[l]["Cost"] = powerpoints * 2
				#result[l]["OldCost"] = 0
				#result[l]["Multiplier"] = powerpoints
				#result[l]["BrawlerID"] = brawler
				#result[l]["SkinID"] = 0
				#result[l]["WhoBuyed"] = []
				#result[l]["ShopType"] = 1
				#result[l]["ShopDisplay"] = 1
				#json.dumps(result)
				#ind += 1
			#else:
				#break
		OfferGenerator.newOffers(self, result)

	def newOffers(self, result):
		with open("JSON/offers.json", "w") as f:
			json.dump(result,f)

	def deleteOffers(self):
		with open("JSON/offers.json", "w") as f:
			data = {}
			json.dump(data,f)